# -*- coding: utf-8 -*-

import os
import sys
import datetime
import time
import numpy as np
from pathlib import Path
import re
import cv2
import tifffile as tiff
from osgeo import gdal_array

import tensorflow as tf
from keras import backend as K

#************************************************************************
sys.path.append('.')
from addict import Dict
from tools.utils import set_seed,yaml_load_from_file
from tools.modelBuilder import modelCreate
#======================================================================================================
def model_predict_by_weights(model,weight_fullpath,imgs_dir,imgResult_dir,tile_size):
    # load the trained convolutional neural network
    print("[INFO] loading network...")
    now_time=datetime.datetime.now().strftime(r'%Y%m%d%H%M%S')
    result_suffix=Path(weight_fullpath).stem.split('.')[0]
    K.clear_session()
    model.load_weights(weight_fullpath,skip_mismatch=True)
    imgs_prefixNames= sorted([fname.split('__sats')[0] for fname in os.listdir(imgs_dir)
                              if fname.endswith((".tif",".dat"))])  
                    
    for n in range(len(imgs_prefixNames)):
        start=datetime.datetime.now()
        fname=imgs_prefixNames[n]
        resultName=os.path.splitext(os.path.basename(fname))[0]+'__weights_'+f'{result_suffix}_Produce{now_time}.tif'
        result_fullpath=os.path.join(imgResult_dir,resultName)
        img=gdal_array.LoadFile(os.path.join(imgs_dir,f'{fname}__sats.tif'))
        #**********************************************************************
        img=img if img.shape[2]<=32 else img.transpose([1,2,0])
        oh,ow,b = img.shape
        print(img.shape)
        print(img.dtype)
        
        rh, rw = oh % tile_size, ow % tile_size
        
        height_pad = 0 if rh == 0 else tile_size - rh
        width_pad = 0 if rw == 0 else tile_size - rw
        
        padding_h,padding_w=oh+height_pad,ow+width_pad
        padding_img = np.zeros((padding_h,padding_w,b),dtype=img.dtype)
        
        print('padding.shape=',padding_img.shape)
        padding_img[0:oh,0:ow,:] = img[:,:,:]
        #***********************************************************************
        mask_whole = np.zeros((padding_h,padding_w),dtype=np.uint8)
        for i in range(0,padding_h,tile_size):
            for j in range(0,padding_w,tile_size):
               
                tile=padding_img[i:i+tile_size,j:j+tile_size,:]
                tile = np.expand_dims(tile, axis=0) 
                preds = model.predict(tile,verbose=1)
                probs = tf.nn.sigmoid(preds)
                probs=np.squeeze(probs)
                mask=probs>0.5
                mask_whole[i:i+tile_size,j:j+tile_size] = mask[:,:]
        tiff.imwrite(result_fullpath,mask_whole[0:oh,0:ow,:]*255)
        end=datetime.datetime.now()
        elapse=end-start
#============================================================================================================================
if __name__ == '__main__':
    #*******************************************************
    print(tf.config.list_physical_devices('GPU'))
    set_seed(42)
    #********************************************************
    configFile=Path('./configs/transunet.yaml')
    #********************************************************
    configFile=Path('./configs/village/transunet_village.yaml')
    # configFile=Path('./configs/village/unet_village.yaml')
    # configFile=Path('./configs/village/deeplabv3plus_village.yaml')
    # configFile=Path('./configs/village/transdeeplab_village.yaml')
    #********************************************************
    #********************************************************
    configData=Dict(yaml_load_from_file(configFile))
    model=modelCreate(configData.MODEL.NAME,configData.DATA.TILE_SIZE,
                      configData.DATA.TILE_CHANNELS,configData.MODEL.NUM_CLASSES)
    #*******************************************************************************************
    all_weights=sorted(Path(f'{configData.TRAINING.WEIGHTS_PARENT_DIR}/weights').glob('*.h5'))
    date_lst=[re.findall(r'\d{8}',item.stem)[0] for item in all_weights]
    max_date=max([datetime.datetime.strptime(item, r"%Y%m%d") for item in date_lst])
    max_date_str=datetime.datetime.strftime(max_date, r"%Y%m%d")
    weightsVer=int(configData.TRAINING.END_EPOCH)//10
    weight_fullpath=os.path.join(f'{configData.TRAINING.WEIGHTS_PARENT_DIR}/weights',
                                 f'{configData.TRAINING.WEIGHTS_PREFIX}_{max_date_str}v{weightsVer}.weights.h5')
    #******************************************************************************************
    #for testImgs accuracy assessment
    if Path(weight_fullpath).exists():
        model_predict_by_weights(model,weight_fullpath,configData.TESTING.TESTIMGS_DIR,
                            configData.TESTING.TESTIMGS_RESULT,configData.DATA.TILE_SIZE)

    #***************************************************************************************
    # #for bigImgs inference
    # if Path(weight_fullpath).exists():
    #     model_predict_by_weights(model,weight_fullpath,configData.TESTING.BIGIMGS_DIR,
    #                         configData.TESTING.BIGIMGS_RESULT,configData.DATA.TILE_SIZE)
    #***************************************************************************************
    
    