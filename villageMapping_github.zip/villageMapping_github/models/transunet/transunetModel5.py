# _*_ coding: utf-8 _*_

##*********************************************************************************************
import os
import sys
os.environ["KERAS_BACKEND"] = "tensorflow"  # @param ["tensorflow", "jax", "torch"]

import tensorflow as tf
import keras
from keras import layers
from keras import ops
sys.path.append('.')
from resnet.resnet_v2 import ResNet50V2
from transformer_kerascv import transformer_encoder_rev,vit_layers_rev


##************************************************************************
def get_backbone(backbone=None):
    c4b6_output, c3b4_output, c2b3_output ,c1= [
        backbone.get_layer(layer_name).output
        for layer_name in ["conv4_block6_preact_relu","conv3_block4_preact_relu", "conv2_block3_preact_relu", "conv1_conv"]
    ]
   
    return [c4b6_output, c3b4_output, c2b3_output ,c1]
##****************************************************************
def convolution_block(
    block_input,
    num_filters=256,
    kernel_size=3,
    strides=1,
    dilation_rate=1,
    use_bias=False,
):
    x = layers.Conv2D(
        num_filters,
        kernel_size=kernel_size,
        strides=strides,
        dilation_rate=dilation_rate,
        padding="same",
        use_bias=use_bias,
        kernel_initializer=keras.initializers.HeNormal(),
    )(block_input)
    x = layers.BatchNormalization()(x)
    return ops.nn.relu(x)

def decoder_ops(lowFeatures,represent):
    c3b4_output, c2b3_output ,c1=lowFeatures
    y=convolution_block(represent,num_filters=512,kernel_size=3)
    #64
    y=layers.UpSampling2D(size=2,interpolation='bilinear')(y)
    y=layers.Concatenate(axis=-1)([y,c3b4_output])
    y=convolution_block(y,num_filters=256,kernel_size=3)
    y=convolution_block(y,num_filters=256,kernel_size=3)
    #128
    y=layers.UpSampling2D(size=2,interpolation='bilinear')(y)
    y=layers.Concatenate(axis=-1)([y,c2b3_output])
    y=convolution_block(y,num_filters=128,kernel_size=3)
    y=convolution_block(y,num_filters=128,kernel_size=3)
    #256
    y=layers.UpSampling2D(size=2,interpolation='bilinear')(y)
    y=layers.Concatenate(axis=-1)([y,c1])
    y=convolution_block(y,num_filters=64,kernel_size=3)
    y=convolution_block(y,num_filters=64,kernel_size=3)
    #512
    y=layers.UpSampling2D(size=2,interpolation='bilinear')(y)
    y=convolution_block(y,num_filters=16,kernel_size=3)
    y=convolution_block(y,num_filters=16,kernel_size=3)

    return y

##***************************************************************************************
def TransformerBlock(img_batch,
                     project_dim=1024,
                     num_heads=4,
                     mlp_dim=3072,
                     transformer_layers=12,
                     ):
    
   
    height=img_batch.shape[1]
    encoded_patches = vit_layers_rev.PatchingAndEmbedding(project_dim=project_dim,patch_size=1,padding='SAME')(img_batch)[:,1:,:]
  
    
    for _ in range(transformer_layers):
        y1=transformer_encoder_rev.TransformerEncoder(project_dim=project_dim,num_heads=num_heads,mlp_dim = mlp_dim)(encoded_patches)
        encoded_patches=y1

    
    representation = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
    representation=layers.Reshape(target_shape=(height,height,-1))(encoded_patches)
   
    return representation
    

##***************************************************************************************


def create_transunet(tile_size=512, num_channels=14,num_classes=1):
                     
    
    resnet50v2=ResNet50V2(include_top=False, input_shape=(tile_size,tile_size,num_channels),weights=None)
    c4b6_output, c3b4_output, c2b3_output ,c1=get_backbone(resnet50v2)
    representation=TransformerBlock(c4b6_output)
    y=decoder_ops([c3b4_output, c2b3_output ,c1],representation)
    logits = layers.Conv2D(num_classes, 1)(y)
   
    model = keras.Model(inputs=resnet50v2.input, outputs=logits)
    return model




if __name__=='__main__':
              
    pass
