# -*- coding: utf-8 -*-
import sys

sys.path.append('.')
from models.transunet.transunetModel5 import create_transunet
from models.unet.unetModel_ResNet50V2 import create_unet_ResNet50V2
from models.deeplabv3.deeplabv3plusModel import create_DeeplabV3Plus_ResNet50V2
from models.transdeeplab.TransDeeplabv3plusModel import create_TransDeeplabV3Plus_ResNet50V2
#===============================================================================================
def modelCreate(modelName,tile_size=512, tile_channels=14,num_classes=1):
    if modelName=='transunet':
        return create_transunet(tile_size, tile_channels,num_classes)
    elif modelName=='unet_ResNet50V2':
        return create_unet_ResNet50V2(tile_size, tile_channels,num_classes)
    elif modelName=='deeplabv3+':
        return create_DeeplabV3Plus_ResNet50V2(tile_size, tile_channels,num_classes)
    elif modelName=='transdeeplab':
        return create_TransDeeplabV3Plus_ResNet50V2(tile_size, tile_channels,num_classes)
#==========================================================================================

if __name__=='__main__':
    
    pass