# -*- coding: utf-8 -*-
import os
import sys
import argparse
from pathlib import Path
import random
import math
import numpy as np
from ruamel.yaml import YAML,comments
import yaml
sys.path.append('.')

#===============================================================================================
def set_seed(rand_num=42):
    # for hash
    os.environ['PYTHONHASHSEED'] = str(rand_num)
    # for python and numpy
    random.seed(rand_num)
    np.random.seed(rand_num)
#==========================================================================================
def yaml_load_from_file(cfg_file):
    with open(cfg_file, 'r') as f:
        yaml_cfg = yaml.load(f, Loader=yaml.FullLoader)
    print(type(yaml_cfg))
    print(yaml_cfg)
    return yaml_cfg

#===============================================================================================
if __name__=='__main__':
    
    pass